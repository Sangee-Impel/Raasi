var base = require('settings/subscription/subscribe-braintree');

Vue.component('spark-subscribe-braintree', {
    mixins: [base]
});
