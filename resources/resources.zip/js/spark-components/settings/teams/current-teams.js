var base = require('settings/teams/current-teams');

Vue.component('spark-current-teams', {
    mixins: [base]
});
