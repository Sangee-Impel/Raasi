var base = require('settings/teams/pending-invitations');

Vue.component('spark-pending-invitations', {
    mixins: [base]
});
