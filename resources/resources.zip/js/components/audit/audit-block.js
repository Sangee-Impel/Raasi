Vue.component('audit-block', {

    data() {
        return {
            customer_id      : null,
        };
    },

    created(){

    },
    beforeDestroy(){

    },
    mounted(){
    },
});
