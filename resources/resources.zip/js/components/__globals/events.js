export const Events = {
    CUSTOMER_PROFILE : 'customer-profile'
};
