Vue.component('dashboard', {
    components : {

    },
    data() {
        return {
            isLoading       : false,

        };
    },

    created(){

    },
    beforeDestroy(){

    },
    mounted(){
        console.log("list");
        // this.isLoading = false;
    },
    computed:{

    },

    methods : {
        


    }
});
