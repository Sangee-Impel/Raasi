  @extends('layouts.home')

@section('content')
    <dashboard inline-template>
        <div class="padding">
            @include('__global.loading')
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12">
                    <div class="box">
                        <div class="box-header">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="app-body  bg-auto w-full">
                                        <div class="text-center pos-rlt p-y-md">
                                            <h2 class="h1 m-y-lg text-black">UNDER CONSTRUCTION</h2>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </dashboard>
@endsection
