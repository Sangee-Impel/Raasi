<script src="{{ mix('js/app.js') }}"></script>

<!-- Jquery Core Js -->
<script type="text/javascript" src="{{asset('libs/jquery/jquery/dist/jquery.js')}}"></script>
<script type="text/javascript" src="{{asset('libs/jquery/tether/dist/js/tether.min.js')}}"></script>
<script type="text/javascript" src="{{asset('libs/jquery/bootstrap/dist/js/bootstrap.js')}}"></script>

<script type="text/javascript" src="{{asset('libs/jquery/PACE/pace.min.js')}}"></script>

<script type="text/javascript" src="{{asset('libs/jquery/jQuery-Storage-API/jquery.storageapi.min.js')}}"></script>
<script type="text/javascript" src="{{asset('libs/scripts/ui-load.js')}}"></script>
<script type="text/javascript" src="{{asset('libs/scripts/config.lazyload.js')}}"></script>
<script type="text/javascript" src="{{asset('libs/scripts/ui-jp.js')}}"></script>
<script type="text/javascript" src="{{asset('libs/scripts/ui-include.js')}}"></script>
<script type="text/javascript" src="{{asset('libs/scripts/ui-toggle-class.js')}}"></script>
<script type="text/javascript" src="{{asset('libs/scripts/ui-scroll-to.js')}}"></script>

<script type="text/javascript" src="{{asset('libs/scripts/ui-nav.js')}}"></script>


<!--
<script type="text/javascript" src="{{asset('gritter/js/jquery.gritter.js')}}"></script>

<script type="text/javascript" src="{{asset('libs/jquery/underscore/underscore-min.js')}}"></script>

<script type="text/javascript" src="{{asset('libs/scripts/palette.js')}}"></script>
<script type="text/javascript" src="{{asset('libs/scripts/ui-device.js')}}"></script>
<script type="text/javascript" src="{{asset('libs/scripts/ui-form.js')}}"></script>
<script type="text/javascript" src="{{asset('libs/scripts/ui-screenfull.js')}}"></script>
<script type="text/javascript" src="{{asset('libs/jquery/jquery-pjax/jquery.pjax.js')}}"></script>
<script type="text/javascript" src="{{asset('libs/scripts/ajax.js')}}"></script>
-->
<script type="text/javascript" src="{{asset('libs/scripts/app.js')}}"></script>


