<div class="app-footer">
    <div class="p-2 text-xs">
        <div class="pull-right text-muted py-1">
            &copy; Copyright <strong>Nexgenx</strong>
        </div>
    </div>
</div>