<link href="{{ asset('css/app.css') }}" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="{{asset('animate.css/animate.min.css')}}">

<link rel="stylesheet" type="text/css" href="{{asset('glyphicons/glyphicons.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('font-awesome/css/font-awesome.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('material-design-icons/material-design-icons.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('bootstrap/dist/css/bootstrap.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('styles/app.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('fonts/roboto/font.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('styles/font.css')}}">

<!--Gritter plugin for notification-->
<!--<link rel="stylesheet" type="text/css" href="{{asset('gritter/css/jquery.gritter.css')}}">-->
