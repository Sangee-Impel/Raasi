<?php

namespace App\Models;

use App\GenXCommon\XModel;
use Illuminate\Database\Eloquent\Model;

class Audit extends XModel
{
    //

    public $table = "audits";
}
